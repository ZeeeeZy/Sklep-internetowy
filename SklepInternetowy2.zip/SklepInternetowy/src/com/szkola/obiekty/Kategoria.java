package com.szkola.obiekty;

public enum Kategoria {
    TELEWIZORY("TELEWIZORY"),
    LAPTOPY("LAPTOPY"),
    TELEFONY("TELEFONY"),
    KOMPUTERY("KOMPUTERY"),
    ZEGARKI("ZEGARKI");

    Kategoria(String typ) {

    }
}
