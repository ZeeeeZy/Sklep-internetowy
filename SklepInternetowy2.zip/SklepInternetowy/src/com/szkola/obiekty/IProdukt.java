package com.szkola.obiekty;

public interface IProdukt {
}
