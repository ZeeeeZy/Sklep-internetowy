package com.szkola.enums;

public enum RodzajEkranu {
    LED("LED"), OLED("OLED"), LCD("LCD"), AMOLED("AMOLED");

    RodzajEkranu(String typ) {
    }
}
