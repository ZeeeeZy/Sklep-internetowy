package com.szkola.enums;

public enum Bransoleta {
    METALOWA("METALOWA"), MATERIAŁOWA("MATERIAŁOWA"), SKORZANA("SKÓRZANA");


    Bransoleta(String material) {
    }
}
