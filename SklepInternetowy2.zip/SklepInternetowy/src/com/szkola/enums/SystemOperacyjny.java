package com.szkola.enums;

public enum SystemOperacyjny {

    WINDOWS("WINDOWS"), LINUX("LINUX"), MACOS("MACOS"), ANDROID("ANDROID"), IOS("IOS");

    SystemOperacyjny(String system) {

    }
}
