package com.szkola.enums;

public enum TypZegarka {
    MECHANICZNY("MECHANICZNY"), KWARCOWY("KWARCOWY"), SMARTWATCH("SMARTWATCH");

    TypZegarka(String typ) {
    }
}
