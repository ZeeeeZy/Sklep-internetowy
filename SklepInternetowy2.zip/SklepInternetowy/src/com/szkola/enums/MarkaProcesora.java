package com.szkola.enums;

public enum MarkaProcesora {
    INTEL("INTEL"), AMD("AMD"), APPLE("APPLE");

    MarkaProcesora(String marka) {

    }
}
