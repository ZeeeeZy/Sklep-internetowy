package com.szkola.iterators;

public interface Container {
    public Iterator getIterator();
}